using System;
using System.Collections.Generic;
using UnityEngine;
namespace GripRehab {
// Exact closest points on local triangles adjacent to the closest mesh vertex.
// Uses cached topology and the deformation backend's live vertices; no cooking,
// convex-hull conversion, or per-frame mesh.vertices allocation.
public sealed class MeshContactSurface {
 readonly int[] triangles;readonly int[][] adjacent;readonly Transform visual;
 public MeshContactSurface(Mesh mesh,Transform visual){
  this.visual=visual;triangles=mesh.triangles;var lists=new List<int>[mesh.vertexCount];for(int i=0;i<lists.Length;i++)lists[i]=new List<int>();
  for(int t=0;t<triangles.Length;t+=3)for(int k=0;k<3;k++)lists[triangles[t+k]].Add(t);
  adjacent=new int[lists.Length][];for(int i=0;i<lists.Length;i++)adjacent[i]=lists[i].ToArray();
 }
 public bool Closest(Vector3 world,Vector3[] vertices,out Vector3 point,out Vector3 normal){
  point=normal=Vector3.zero;if(vertices==null||vertices.Length!=adjacent.Length||!HandRigRules.Finite(world))return false;
  var local=visual.InverseTransformPoint(world);int nearest=-1;float best=float.PositiveInfinity;
  for(int i=0;i<vertices.Length;i++){float d=visual.TransformVector(vertices[i]-local).sqrMagnitude;if(d<best){best=d;nearest=i;}}
  if(nearest<0)return false;best=float.PositiveInfinity;Vector3 n=Vector3.zero,p=Vector3.zero;
  foreach(int t in adjacent[nearest]){var a=visual.TransformPoint(vertices[triangles[t]]);var b=visual.TransformPoint(vertices[triangles[t+1]]);var c=visual.TransformPoint(vertices[triangles[t+2]]);var faceNormal=Vector3.Cross(b-a,c-a);if(faceNormal.sqrMagnitude<1e-24f)continue;var candidate=Triangle(world,a,b,c);
   float d=(candidate-world).sqrMagnitude;if(d<best){best=d;p=candidate;n=faceNormal;}}
  if(n.sqrMagnitude<1e-24f)return false;point=p;
  // Vector3.normalized zeros vectors below Unity's generic epsilon; valid
  // small mesh triangles have area vectors far below that threshold.
  normal=n/Mathf.Sqrt(n.sqrMagnitude);return HandRigRules.Finite(normal);
 }
 // Ericson closest-point regions, implemented locally; degenerate edges safe.
 static Vector3 Triangle(Vector3 p,Vector3 a,Vector3 b,Vector3 c){
  var ab=b-a;var ac=c-a;var ap=p-a;float d1=Vector3.Dot(ab,ap),d2=Vector3.Dot(ac,ap);if(d1<=0&&d2<=0)return a;
  var bp=p-b;float d3=Vector3.Dot(ab,bp),d4=Vector3.Dot(ac,bp);if(d3>=0&&d4<=d3)return b;
  float vc=d1*d4-d3*d2;if(vc<=0&&d1>=0&&d3<=0)return a+ab*(d1/Mathf.Max(1e-12f,d1-d3));
  var cp=p-c;float d5=Vector3.Dot(ab,cp),d6=Vector3.Dot(ac,cp);if(d6>=0&&d5<=d6)return c;
  float vb=d5*d2-d1*d6;if(vb<=0&&d2>=0&&d6<=0)return a+ac*(d2/Mathf.Max(1e-12f,d2-d6));
  float va=d3*d6-d5*d4;if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0)return b+(c-b)*((d4-d3)/Mathf.Max(1e-12f,(d4-d3)+(d5-d6)));
  float sum=va+vb+vc;if(Mathf.Abs(sum)<1e-24f)return a;return a+ab*(vb/sum)+ac*(vc/sum);
 }
}
}
